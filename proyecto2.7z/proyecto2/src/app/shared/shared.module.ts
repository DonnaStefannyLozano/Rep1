import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; // Asegúrate de importar CommonModule
import { NavbarComponent } from '../navbar/navbar.component'; // Importar el componente Navbar
import { RouterModule } from '@angular/router';  // Importar RouterModule

@NgModule({
  declarations: [
    NavbarComponent 
  ],
  imports: [
    CommonModule,
    RouterModule  
  ],
  exports: [
    NavbarComponent 
  ]
})
export class SharedModule { }
