import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SharedModule } from './shared/shared.module'; 

@NgModule({
  declarations: [
    LoginComponent  
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule,
    SharedModule  
  ],
  providers: [],
  bootstrap: [LoginComponent] 
})
export class AppModule { }
