import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrarProductosComponent } from './registrar-productos/registrar-productos.component';
import { RegistrarUsuariosComponent } from './registrar-usuarios/registrar-usuarios.component';
import { ListarProductosComponent } from './listar-productos/listar-productos.component';
import { LoginComponent } from './login/login.component';
import { ListarUsuariosComponent } from './listar-usuarios/listar-usuarios.component';

export const routes: Routes = [
  { path: 'registrarProducto', component: RegistrarProductosComponent },
  { path: 'registrarUsuarios', component: RegistrarUsuariosComponent },
  { path: 'listarProductos', component: ListarProductosComponent },
  { path: 'listarUsuarios', component: ListarUsuariosComponent},
  { path: 'login', component: LoginComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], // Aquí es donde ocurre el error
  exports: [RouterModule]
})
export class AppRoutingModule { }