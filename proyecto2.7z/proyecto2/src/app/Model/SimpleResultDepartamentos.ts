import { Departamento } from './SimpleresultDep'; // Ajusta la ruta según tu estructura de proyecto

export { Departamento }; // Asegúrate de exportar Departamento

export class SimpleResultDepartamentos {
  departamentos: Departamento[];

  constructor(departamentos: Departamento[]) {
    this.departamentos = departamentos;
  }
}
