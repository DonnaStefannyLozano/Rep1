export class Municipio {
    id: number;
    ciudad: string;
    departamentoId: number;
  
    constructor(id: number, ciudad: string, departamentoId: number) {
      this.id = id;
      this.ciudad = ciudad;
      this.departamentoId = departamentoId;
    }
  }
  