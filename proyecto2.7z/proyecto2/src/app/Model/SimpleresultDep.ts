import { Municipio } from './SimpleResultMuni'; // Asegúrate de ajustar la ruta según tu estructura

export class Departamento {
  id: number;
  nombre: string;
  municipios: Municipio[];

  constructor(id: number, nombre: string, municipios: Municipio[]) {
    this.id = id;
    this.nombre = nombre;
    this.municipios = municipios;
  }
}
