const express = require('express');
const mysql = require('mysql');
const app = express();
const port = 3000;
const cors = require('cors'); 


// Configurar conexión a MySQL
const connection = mysql.createConnection({
    host: 'localhost', // Cambia según tu configuración
    user: 'root',       // Tu usuario de MySQL
    password: '',       // Tu contraseña de MySQL
    database: 'personalchef'
});

// Conectar a la base de datos
connection.connect(err => {
    if (err) {
        console.error('Error de conexión: ' + err.stack);
        return;
    }
    console.log('Conectado a la base de datos.');
});
app.use(cors());
app.use(express.json());

// Ejemplo de ruta para obtener los productos
app.get('/productos', (req, res) => {
    // Realiza una consulta a la base de datos
    connection.query('SELECT * FROM producto', (err, results) => {
      if (err) {
        // Enviar error y asegurarse de que solo se envía una respuesta
        if (!res.headersSent) {
          return res.status(500).json({ message: 'Error en la consulta a la base de datos' });
        }
      }
      
      // Verifica si ya se envió una respuesta
      if (!res.headersSent) {
        // Envía la respuesta con los resultados de la consulta
        return res.status(200).json(results);
      }
    });
});

// Ruta para insertar un nuevo producto
app.post('/productos', (req, res) => {
    const { nombre, descripcion, precio, categoria, imagen_url } = req.body;

    const query = `
        INSERT INTO producto (nombre, descripcion, precio, categoria, imagen_url)
        VALUES (?, ?, ?, ?, ?)
    `;

    // Ejecutamos la consulta con los valores enviados en el cuerpo de la solicitud (req.body)
    connection.query(query, [nombre, descripcion, precio, categoria, imagen_url], (err, result) => {
        if (err) {
            return res.status(500).send(err);  // Enviar el error en caso de fallo
        }

        res.json({
            message: 'Producto insertado correctamente',
            insertedId: result.insertId  // Devolver el ID del producto insertado
        });
    });
});


app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});


