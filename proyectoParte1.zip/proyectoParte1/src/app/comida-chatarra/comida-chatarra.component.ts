import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../services/login-service.service';
import { SimpleResult } from '../Model/SimpleResult';

@Component({
  selector: 'app-comida-chatarra',
  templateUrl: './comida-chatarra.component.html',
  styleUrls: ['../bebidas/bebidas.component.css']
})
export class ComidaChatarraComponent implements OnInit{
  categoria: SimpleResult[] = [];
  constructor(private loginServiceService: LoginServiceService){

  }
  ngOnInit(): void {
    
    this.productos();
  }

  productos(){
    this.loginServiceService.productos().subscribe({
      next: (producData) => {
        this.categoria = producData.filter(prod => prod.categoria === 'Comida Chatarra');
        console.log("productos: ", this.categoria);
      },
      error: (errorData) => {
        console.error( "Error obteniendo Productos...");
      },
      complete: () => {
        console.info("Productos completado...");
      }
    });
  }

}
