import { Component, OnInit } from '@angular/core';
import { SimpleResult } from '../Model/SimpleResult';
import { LoginServiceService } from '../services/login-service.service';

@Component({
  selector: 'app-comida-vegetariana',
  templateUrl: './comida-vegetariana.component.html',
  styleUrls: ['../bebidas/bebidas.component.css']
})
export class ComidaVegetarianaComponent implements OnInit {
  categoria: SimpleResult[] = [];
  constructor(private loginServiceService: LoginServiceService){

  }
  ngOnInit(): void {
    
    this.productos();
  }

  productos(){
    this.loginServiceService.productos().subscribe({
      next: (producData) => {
        this.categoria = producData.filter(prod => prod.categoria === 'Vegetariana');
        console.log("productos: ", this.categoria);
      },
      error: (errorData) => {
        console.error( "Error obteniendo Productos...");
      },
      complete: () => {
        console.info("Productos completado...");
      }
    });
  }

}
