import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';

import { PedidoComponent } from './pedido/pedido.component';
import { BebidasComponent } from './bebidas/bebidas.component';
import { ComidaChatarraComponent } from './comida-chatarra/comida-chatarra.component';
import { ComidaVegetarianaComponent } from './comida-vegetariana/comida-vegetariana.component';

@NgModule({
  declarations: [
    LoginComponent,
    PedidoComponent,
    BebidasComponent,
    ComidaChatarraComponent,
    ComidaVegetarianaComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [LoginComponent] 
})
export class AppModule { }
